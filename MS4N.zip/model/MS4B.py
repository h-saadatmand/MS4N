#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  9 17:23:09 2026

@author: user1
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-



import math
import torch
import torch.nn as nn
from einops import repeat


# ============================================================
# 1. DropoutNd
# ============================================================

class DropoutNd(nn.Module):
    """N-dimensional dropout that drops entire feature channels."""
    def __init__(self, p: float = 0.5):
        super().__init__()
        if not (0 <= p <= 1):
            raise ValueError(f"dropout probability must be between 0 and 1, got {p}")
        self.p = p

    def forward(self, x):
        if not self.training or self.p == 0:
            return x
        shape = list(x.shape)
        shape[2:] = [1] * len(shape[2:])
        mask = torch.bernoulli(torch.full(shape, 1 - self.p, device=x.device, dtype=x.dtype))
        return x * mask / (1 - self.p)


# ============================================================
# 2. S4DKernel (Standard)
# ============================================================

class S4DKernel(nn.Module):
    """Standard S4D kernel """

    def __init__(self, d_model, N=64, dt_min=0.001, dt_max=0.1, lr=None):
        super().__init__()
        H = d_model

        log_dt = torch.rand(H) * (math.log(dt_max) - math.log(dt_min)) + math.log(dt_min)
        self.register("log_dt", log_dt, lr)

        C = torch.randn(H, N // 2, dtype=torch.cfloat)
        self.C = nn.Parameter(torch.view_as_real(C))
        self.B = nn.Parameter(torch.ones(H, N // 2))
        
        log_A_real = torch.log(0.5 * torch.ones(H, N // 2))
        A_imag = math.pi * repeat(torch.arange(N // 2), 'n -> h n', h=H)
        self.register("log_A_real", log_A_real, lr)
        self.register("A_imag", A_imag, lr)

    def forward(self, L):
        dt = torch.exp(self.log_dt)
        C = torch.view_as_complex(self.C)
        A = -torch.exp(self.log_A_real) + 1j * self.A_imag

        dtA = A * dt.unsqueeze(-1)*self.B
        A_bar = torch.exp(dtA)
        B_bar = ((A_bar - 1.0) / A) 

        k = torch.arange(L, device=A.device)
        A_pow = A_bar.unsqueeze(-1) ** k.unsqueeze(0).unsqueeze(0)
        CB = C * B_bar
        K = torch.einsum('hn,hnl->hl', CB, A_pow)
        K = 2 * K.real
        return K

    def register(self, name, tensor, lr=None):
        if lr == 0.0:
            self.register_buffer(name, tensor)
        else:
            self.register_parameter(name, nn.Parameter(tensor))
            optim = {"weight_decay": 0.0}
            if lr is not None:
                optim["lr"] = lr
            getattr(self, name)._optim = optim


# ============================================================
# 3. S4D Layer 
# ============================================================

class S4D(nn.Module):
  
    def __init__(self, d_model, d_state=64, dropout=0.0, transposed=True, 
                  **kernel_args):
        super().__init__()
        self.h = d_model
        self.n = d_state
        self.transposed = transposed
        

        self.D = nn.Parameter(torch.randn(self.h))
        self.kernel = S4DKernel(self.h, N=self.n, **kernel_args)

        

        self.activation = nn.GELU()
        self.dropout = DropoutNd(dropout) if dropout > 0.0 else nn.Identity()
        self.output_linear = nn.Sequential(
            nn.Conv1d(self.h, 2 * self.h, kernel_size=1),
            nn.GLU(dim=-2),
        )

    def forward(self, u, **kwargs):

        if not self.transposed:
            u = u.transpose(-1, -2)

        B, H, L = u.shape
        
        # Step 1: Transform to frequency domain
        k = self.kernel(L=L)
        k_f = torch.fft.rfft(k, n=2 * L)
        u_f = torch.fft.rfft(u, n=2 * L)
        
        # Step 2: Convolution in frequency domain (K ⊛ u)
        conv_f = k_f * u_f
        
        # Step 3: Transform back to time domain
        y_conv = torch.fft.irfft(conv_f, n=2 * L)[..., :L]
        
        # Step 4: Add feedthrough D*u in time domain
        D = self.D.unsqueeze(0).unsqueeze(-1)
        y = y_conv + u * D

        # Step 5: Add non-linearity and regularization
        y = self.dropout(self.activation(y))
        
        # Step 6: Channel Mixing
        y = self.output_linear(y)

        if not self.transposed:
            y = y.transpose(-1, -2)
            
        return y


# ============================================================
# 4. S4DBlock
# ============================================================

class S4DBlock(nn.Module):
    """Wrapper around S4D with projection."""
    def __init__(self, input_dim=3, d_model=64, d_state=64, dropout=0.0, 
                 ):
        super().__init__()
        self.project_in = nn.Linear(input_dim, d_model)
        self.s4d = S4D(
            d_model=d_model, d_state=d_state, dropout=dropout, transposed=True,
            
        )

    def forward(self, x):
        x = self.project_in(x)
        x = x.permute(0, 2, 1)
        x = self.s4d(x)
        x = x.permute(0, 2, 1)
        return x


# ============================================================
# 5. S4DStackedLayers
# ============================================================

class S4DStackedLayers(nn.Module):
    """Stack of multiple S4D layers with residual connections."""
    def __init__(self, input_dim=3, d_model=64, d_state=64, dropout=0.0, 
                  num_layers=2):
        super().__init__()
        self.num_layers = num_layers
        self.d_model = d_model
        
        # First layer: projects input_dim -> d_model
        self.layers = nn.ModuleList([
            S4DBlock(input_dim, d_model, d_state, dropout, )
        ])
        
        # Subsequent layers: d_model -> d_model
        for _ in range(num_layers - 1):
            self.layers.append(
                S4DBlock(d_model, d_model, d_state, dropout, )
            )
        
        # Layer normalization for each layer
        #self.layer_norms = nn.ModuleList([
            #nn.LayerNorm(d_model) for _ in range(num_layers)
        #])

    def forward(self, x):
        """
        Args:
            x: (B, L, input_dim) for first layer
        Returns:
            x: (B, L, d_model)
        """
        for i, (layer) in enumerate(self.layers):
            if i == 0:
                x = layer(x)
            else:
                x = x + layer(x)
           # x = norm(x)
        return x



# ============================================================
# 6. S4Classifier
# ============================================================

class S4Classifier(nn.Module):
    """
    Full S4D classifier with multiple layers.
    Configurable through a config dictionary or direct arguments.
    """

    def __init__(self, 
                 config: dict, 
                 num_classes: int = None,
                 num_layers: int = None,
                 d_model: int = None,
                 d_state: int = None):

        super().__init__()
        
        # ----------------------------------------------------
        # Extract data shape
        # ----------------------------------------------------
        self.input_dim = config['Data_shape'][1]   # C
        self.seq_len = config['Data_shape'][2]     # L
        self.num_classes = num_classes or config['num_labels']

        # ----------------------------------------------------
        # Hyperparameters
        # ----------------------------------------------------
        self.d_model = d_model or config.get('d_model', 64)
        self.d_state = d_state or config.get('d_state', 64)
        self.num_layers = num_layers or config.get('num_layers', 1)
        self.dropout = config.get('dropout', 0.2)

        # ----------------------------------------------------
        # S4D Layer Stack
        # ----------------------------------------------------
        self.s4d_stack = S4DStackedLayers(
            input_dim=self.input_dim,
            d_model=self.d_model,
            d_state=self.d_state,
            dropout=self.dropout,
            num_layers=self.num_layers
        )

        # ----------------------------------------------------
        # Classification Head
        # ----------------------------------------------------
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),        # (B, d_model, 1)
            nn.Flatten(),                   # (B, d_model)
            nn.Linear(self.d_model, self.d_model),
            nn.GELU(),
            nn.Dropout(self.dropout),       # ← DROPout added properly
            nn.Linear(self.d_model, self.num_classes),
        )


    def forward(self, x):
        """
        Args:
            x: shape (B, C, L) or (B, L, C)
        Returns:
            logits: (B, num_classes)
        """

        # ----------------------------------------------------
        # Ensure input has shape (B, L, C)
        # ----------------------------------------------------
        if x.shape[1] == self.input_dim and x.shape[2] == self.seq_len:
            # x is (B, C, L) → convert to (B, L, C)
            x = x.permute(0, 2, 1)

        # ----------------------------------------------------
        # S4D Stack
        # ----------------------------------------------------
        x = self.s4d_stack(x)              # (B, L, d_model)

        # Prepare for 1D pooling
        x = x.permute(0, 2, 1)             # (B, d_model, L)

        # ----------------------------------------------------
        # Classifier head
        # ----------------------------------------------------
        logits = self.classifier(x)        # (B, num_classes)

        return logits

    